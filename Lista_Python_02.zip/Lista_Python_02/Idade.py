jovens = 0
adultos = 0
idosos = 0
n = 0

while n != "nao":
    idade = int(n)
    if 25 < idade <= 60:
        adultos = adultos + 1
    elif 60 < idade:
        idosos = idosos + 1
    elif idade <= 25:
       jovens = jovens + 1
    else:
        break
    
    n = (input("Digite a idade do usuário (escreva 'nao' caso concluído): "))

print(f"{jovens - 1} têm até 25 anos, {adultos} têm entre 26 e 60 anos, {idosos} têm mais de 60 anos.")
