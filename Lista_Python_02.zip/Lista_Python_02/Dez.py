valor = 0
valor = int(input("Digite seu número (0-10): "))

while valor > 10 or valor < 0:
    print("Número inválido.")
    valor = int(input("Digite seu número (0-10): "))
for i in range(valor + 1):
    tabuada = valor * i
    print(f" {valor} x {i} = {tabuada}")

