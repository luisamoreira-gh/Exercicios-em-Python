login_correto = "Aluno"
senha_correta = int("12345")

login_usuario = input("Digite seu login: ")
senha_usuario = int(input("Digite sua senha: "))

if login_correto == login_usuario and senha_correta == senha_usuario:
    print("Você está logado.")
else:
    print("Login ou senha incorretos.")