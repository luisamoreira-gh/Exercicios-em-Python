valor = int(input("Digite o valor: "))

if valor % 2 == 0:
    for i in range(0, valor + 1, 2):
        print(i)
else:
    for i in range(1, valor + 1, 2):
        print(i)