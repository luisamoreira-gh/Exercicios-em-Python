val1 = int(input("Digite o primeiro valor: "))
val2 = int(input("Digite o segundo valor: "))

soma = val1 + val2
if soma % 2 == 0:
    print(f"A soma dos números é igual a {soma}, um número par!")
else:
    print(f"A soma dos números é igual a {soma}, um número ímpar!")