soma = 0

for i in range(6):
    numeros = int(input("Digite seu número: "))
    soma = soma + numeros

media = soma / 6
print(f"Sua soma é {soma} e sua média é {media}.")