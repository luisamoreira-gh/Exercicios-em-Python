x = 0
x1 = 0
placeholder = 1
n = int(input("Digite seu número: "))

print(0)
while x <= n:
    x1 = x
    x = x + placeholder
    placeholder = x1
    if x <= n:
        print(x)
    else:
        break

    