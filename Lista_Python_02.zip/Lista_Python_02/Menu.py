menu = 0

while menu != 2:
    menu = int(input(" 1- Continuar; 2- Sair "))
    
    if menu == 1:
        print("")
    elif menu == 2:
        print("Você parou :)")
    else:
        print("Número inválido.")