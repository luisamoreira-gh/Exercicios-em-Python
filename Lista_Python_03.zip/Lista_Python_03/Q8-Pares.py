valores = [1, 2, 3, 4, 5, 6, 7, 8]
i = 0

while i < len(valores):
    if valores[i] % 2 == 0:
        i += 1
    else:
        valores.pop(i)

print(valores)