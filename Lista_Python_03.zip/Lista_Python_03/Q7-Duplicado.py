valores = [1, 1, 2, 2, 3, 4, 8, 9, 9]
i = 1

while i < len(valores):
    if valores[i-1] == valores[i]:
        valores.pop(i)
    else:
        i += 1

print(valores)