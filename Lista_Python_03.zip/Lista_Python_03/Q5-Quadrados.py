números = [2, 4, 6, 8]
quadrados = []

for i in range(len(números)):
    resultado = int(números[i]) ** 2
    quadrados.append(resultado)

print(quadrados)