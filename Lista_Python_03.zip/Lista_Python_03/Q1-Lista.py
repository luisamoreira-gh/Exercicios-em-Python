lista = ["Banana", 8, 5.4, True, 99, "Fiat", 10.8, False, "Henrique", 34]
print(lista)