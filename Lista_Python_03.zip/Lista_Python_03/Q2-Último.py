lista = [2, 4, 6, 8, 10, 12, 14]
print(lista)
print(lista[-1])