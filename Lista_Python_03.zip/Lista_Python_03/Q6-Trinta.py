valores = [10, 20, 30, 40, 50]
i = 0

while i < len(valores):
    if valores[i] > 30:
        valores.pop(i)
    else:
        i += 1 # Só avança o índice se não remover nada

print(valores)