lista = [5, 10, 15]
extensao = [25, 30, 35, 40]
print(lista)

lista.extend(extensao)
print(lista)