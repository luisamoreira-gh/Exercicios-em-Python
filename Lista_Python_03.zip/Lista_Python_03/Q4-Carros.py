carros = ["Fiat", "Chevrolet", "Ford", "Honda"]
print(carros)
    
carros.insert(1, "Jeep")
carros.pop(4)
carros.append("Toyota")
print(carros)

print(f"A lista contém {len(carros)} elementos.")

carros_ordenados = sorted(carros)
print(carros_ordenados)