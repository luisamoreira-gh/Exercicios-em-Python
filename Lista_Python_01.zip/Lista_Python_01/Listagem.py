n_1 = int(input("Digite seu primeiro número inteiro: "))
n_2 = int(input("Digite seu segundo número inteiro: "))
n_3 = int(input("Digite seu terceiro número inteiro: "))

if (n_1 > n_2 and n_1 > n_3 and n_2 > n_3) or (n_1 == n_2 and n_1 > n_3 and n_2 > n_3):
    print(f"Sua ordem numérica é: {n_3}, {n_2}, {n_1}.")
elif (n_1 > n_2 and n_3 > n_2 and n_1 > n_3) or (n_1 == n_3 and n_1 > n_2) or (n_2 == n_3 and n_1 > n_2):
    print(f"Sua ordem numérica é: {n_2}, {n_3}, {n_1}.")
elif n_2 > n_1 and n_2 > n_3 and n_1 > n_3:
    print(f"Sua ordem numérica é: {n_3}, {n_1}, {n_2}.")
elif n_3 > n_1 and n_3 > n_2 and n_1 > n_2:
    print(f"Sua ordem numérica é: {n_2}, {n_1}, {n_3}.")
elif (n_2 > n_1 and n_2 > n_3 and n_3 > n_1) or (n_1 == n_3 and n_1 < n_2):
    print(f"Sua ordem numérica é: {n_1}, {n_3}, {n_2}.")
elif (n_3 > n_1 and n_3 > n_2 and n_2 > n_1) or (n_1 == n_2 and n_1 < n_3) or (n_2 == n_3 and n_1 < n_2):
    print(f"Sua ordem numérica é: {n_1}, {n_2}, {n_3}.")
    
elif n_2 == n_3 and n_1 == n_3:
    print(f"Sua ordem numérica é: {n_1}, {n_2}, {n_3}.")