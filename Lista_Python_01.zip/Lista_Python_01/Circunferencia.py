raio = float(input("Digite o raio de sua circunferência (em metros): "))
area = (raio ** 2) * 3.14
print(f"A área do círculo será de {area}m².")