idade = int(input("Digite a sua idade no ano atual: "))
ano_nascimento = 2026 - idade
print(f"Você nasceu no ano de {ano_nascimento}!")