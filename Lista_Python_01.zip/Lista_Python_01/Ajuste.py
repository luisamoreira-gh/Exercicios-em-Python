salario_gerente = 8500
salario_analista = 5000
salario_suporte = 3000

novo_salario_gerente = salario_gerente * 1.12
novo_salario_analista = salario_analista * 1.12
novo_salario_suporte = salario_suporte * 1.15

print(f"Os antigos salários da empresa agora valem R${novo_salario_gerente:.2f} para gerente, R${novo_salario_analista:.2f} para analista, e R${novo_salario_suporte:.2f} para suporte.")