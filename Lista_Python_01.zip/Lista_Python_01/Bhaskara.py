import math

valor_a = float(input("Digite o valor de A: "))
valor_b = float(input("Digite o valor de B: "))
valor_c = float(input("Digite o valor de C: "))

delta = (valor_b ** 2) - (4 * valor_a * valor_c)

if delta < 0:
    print(f"A equação não possui raízes reais, pois delta = {delta}")
else:
    sqrt_delta = math.sqrt(delta)
    
    valor_x1 = (-valor_b + sqrt_delta) / (2 * valor_a)
    valor_x2 = (-valor_b - sqrt_delta) / (2 * valor_a)
    print(f"As raízes da equação são: x1 = {valor_x1}; x2 = {valor_x2}, pois delta = {delta}")